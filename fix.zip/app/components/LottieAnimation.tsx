export default function LottieAnimation() {
  return (
    <div className="w-full h-64 bg-gray-800 rounded-lg flex items-center justify-center">
      <p className="text-white text-lg">Lottie Animation Placeholder</p>
    </div>
  )
}
